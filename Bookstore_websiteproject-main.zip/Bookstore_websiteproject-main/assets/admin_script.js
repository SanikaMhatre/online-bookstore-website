


let usermenu = document.querySelector('#user-btn');
let userdata =document.querySelector('.header .container .user-box');


 usermenu.querySelector('#user-btn').onclick = () =>{
    userdata.classList.toggle('active');
 }
<?php

$conn = mysqli_connect('localhost','root','','bookstore_db') or die('Connection could not be established');


?>